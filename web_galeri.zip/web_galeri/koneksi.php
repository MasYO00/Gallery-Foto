<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "ujikom";

$conn = mysqli_connect($servername, $username, $password, $database);

if (!$conn) {
    die("Koneksi gagal: " . mysqli_error());
} else {
    echo "Koneksi berhasil!";
}

?>