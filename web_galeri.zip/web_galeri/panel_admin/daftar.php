<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ArgalShop - Login Panel System</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="login-container">
            <div class="login-form">
                <form method="post" action="proccess_daftar.php">
                    <div class="box-login">
                        <h2>Register Account</h2>
                        <div class="input-group">
                            <label for="username">Nama</label>
                            <input type="text" id="nama" name="nama" required placeholder="Masukan Nama Lengkap..">
                        </div>
                        <div class="input-group">
                            <label for="username">Email / Username</label>
                            <input type="text" id="email" name="email" required placeholder="Masukan Username / Email Anda..">
                        </div>
                        <div class="input-group">
                            <label for="password">Password</label>
                            <input type="password" id="password" name="password" required placeholder="Masukan Password Anda..">
                        </div>
                        <div class="input-group">
                            <label for="phone">No Telepon</label>
                            <input type="number" id="phone" name="phone" required placeholder="Masukan No Telpon Anda..">
                        </div>
                            <label class="form-label" for="phone">Alamat</label>
                            <textarea class="form-control" name="alamat" placeholder="Masukan Alamat Lengkap Anda.."></textarea>
                        <div class="box-register">
                            <p>
                                Sudah Punya Akun?
                                <a href="login.php">Login Disini !</a>
                            </p>
                        </div>
                        <button type="submit">Register</button>
                    </div>
                </form>
            </div>
        </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>

</body>
</html>
<script src="assets/js/bootstrap.min.js"></script>