<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ArgalShop - Login Panel System</title>
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <div class="login-container">
                <form method="post" action="proccess_login.php">
                    <div class="login-form">
                        <div class="box-login">
                            <h2>Login Panel System</h2>
                            <div class="input-group">
                                <label for="username">Email / Username</label>
                                <input type="text" id="username" name="email" required placeholder="Masukan Username / Email Anda..">
                            </div>
                            <div class="input-group">
                                <label for="password">Password</label>
                                <input type="password" id="password" name="password" required placeholder="Masukan Password Anda..">
                            </div>
                            <div class="box-register">
                                <p>
                                    Sudah Punya Akun?
                                    <a href="daftar.php">Pendaftaran Akun !</a>
                                </p>
                            </div>
                            <button type="submit">Login</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>

</body>
</html>

<script>
    // document.addEventListener('DOMContentLoaded', function () {
    //     const loginForm = document.querySelector('.login-form');

    //     loginForm.addEventListener('submit', function (e) {
    //         e.preventDefault();
    //         const username = document.getElementById('username').value;
    //         const password = document.getElementById('password').value;

    //         if(username !== "admin" || password !== "arya123") {
    //             alert("Username atau Password Salah!");
    //             return;
    //         } else {
    //             alert("Login berhasil!");
    //             window.location.href = "panel_system.php";
    //         }
    //     });
    // });
</script>
<script src="assets/js/bootstrap.min.js"></script>