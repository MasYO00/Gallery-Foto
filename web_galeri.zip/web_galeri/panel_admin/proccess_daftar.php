<?php
    include '../koneksi.php';

    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = $_POST['password'];
    $phone = $_POST['phone'];
    $alamat = $_POST['alamat'];

    $hash_password = password_hash($password, PASSWORD_DEFAULT);

    $query = "INSERT INTO user (nama_lengkap, email, password, level_id, nomber_telfon, alamat) VALUES ('$nama', '$email', '$hash_password', 2 ,'$phone', '$alamat')";
    $result = mysqli_query($conn, $query);

    if($result){
        header('Location: login.php');
    } else {
        echo "Gagal menambah data: " . mysqli_error($conn);
    }

?>