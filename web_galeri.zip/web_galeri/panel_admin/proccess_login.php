<?php
 include '../koneksi.php';
    $username = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT id, email, password FROM user WHERE email='$username'";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['id'] = $row['id'];
            $_SESSION['email'] = $row['email'];
            header("Location: panel_system.php");
        } else {
            echo "Password salah.";
        }
    } else {
        echo "User tidak ditemukan.";
    }
?>